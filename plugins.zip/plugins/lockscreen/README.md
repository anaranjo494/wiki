# Lockscreen Module

In this module:
- Component: KeypadPage
- Service: LockscreenService
- sass/modal.scss (for fullscreen modal): needs to be included in global.scss

Dependencies:
- TapticEngine (https://ionicframework.com/docs/native/taptic-engine)
- FingerprintAIO (https://ionicframework.com/docs/native/fingerprint-aio)
