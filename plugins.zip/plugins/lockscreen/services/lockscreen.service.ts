import { Injectable } from '@angular/core';
import { ModalController, Platform } from '@ionic/angular';
import { KeypadPage } from '../components/keypad/keypad.page';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';

const TYPE_FINGER = 'finger';

@Injectable()
export class LockscreenService {
  authType: string = '';

  constructor(private modalCtrl: ModalController, private fingerprint: FingerprintAIO, private platform: Platform) {

  }

  async verify(options = {}) {
    // Extend the default options
    const extendedOptions = Object.assign({
      passcode: 'none',
      enableTouchIdFaceId: false,
    }, options);

    if (extendedOptions.enableTouchIdFaceId) {
      return this.useTouchIdFaceId()
        .then(() => {
          return {
            data: {
              type: 'dismiss',
              data: true,
            }
          };
        }).catch((error: any) => {
          console.log(`ERROR lock: ${this.authType}`, error);
          extendedOptions.enableTouchIdFaceId = false;
          // return this.useKeypad(extendedOptions);
          if (this.platform.is('ios')) {
            return this.useKeypad(extendedOptions);
          }
        })
    } else {
      return this.useKeypad(extendedOptions);
    }
  }

  async useKeypad(options: object) {
    const modal = await this.modalCtrl.create({
      component: KeypadPage,
      backdropDismiss: false,
      cssClass: 'modal-fullscreen',
      componentProps: {
        ...options
      }
    });

    modal.present();

    return modal.onDidDismiss();
  }

  async useTouchIdFaceId() {
    /*this.authType = TYPE_FINGER ? 'Touch ID' : 'Face ID';

    return this.fingerprint.show({
      title: 'Desbloquar Serenmind',
      subtitle: '',
      description: `Desbloquar con ${this.authType}`, // Only for iOS
      fallbackButtonTitle: 'Entra el PIN de Serenmind', // Only for iOS
      disableBackup: true, // IMPORTANT: We're implementing our own fallback using the keypad UI
    });*/

    return this.fingerprint.isAvailable()
      .then(type => {
        // See more: https://github.com/NiklasMerz/cordova-plugin-fingerprint-aio#check-if-fingerprint-authentication-is-available
        this.authType = type === TYPE_FINGER ? 'Touch ID' : 'Face ID';

        return this.fingerprint.show({
          title: 'Desbloquear Serenmind',
          subtitle: '',
          description: `Desbloquear con ${this.authType}`, // Only for iOS
          fallbackButtonTitle: 'Entra el PIN de Serenmind', // Only for iOS
          disableBackup: true, // IMPORTANT: We're implementing our own fallback using the keypad UI
        });
      });
  }
}
